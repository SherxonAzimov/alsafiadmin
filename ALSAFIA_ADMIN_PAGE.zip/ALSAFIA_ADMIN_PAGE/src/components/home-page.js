import React from 'react';
import "./global.scss"
import Admin from "../adminLayout/admin";

function HomePage() {
    return (
        <>
            <Admin/>
        </>
    );
}

export default HomePage;