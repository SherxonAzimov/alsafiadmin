import React from "react";
import HomePage from "./components/home-page";


function App() {
  return (
    <>
      <HomePage/>
    </>
  );
}

export default App;
